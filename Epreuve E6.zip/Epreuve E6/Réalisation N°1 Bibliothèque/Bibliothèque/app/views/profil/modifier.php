<?php // app/views/profil/modifier.php ?>
<h1 class="page-title">Modifier mon profil</h1>

<?php if (!empty($errors)): ?>
<ul class="errors-list">
    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
</ul>
<?php endif; ?>

<div class="card" style="max-width:500px;">
    <form method="POST" action="<?= BASE_URL ?>/profil/modifier">
        <div class="form-group">
            <label>Adresse e-mail</label>
            <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? $user['email']) ?>">
        </div>
        <div class="form-group">
            <label>Téléphone</label>
            <input type="tel" name="telephone" value="<?= htmlspecialchars($_POST['telephone'] ?? $user['telephone'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Adresse postale</label>
            <input type="text" name="adresse" value="<?= htmlspecialchars($_POST['adresse'] ?? $user['adresse'] ?? '') ?>">
        </div>
        <hr style="margin:1.2rem 0;border:none;border-top:1px solid var(--gray-200);">
        <p class="text-muted mb-2">Laissez les champs ci-dessous vides pour ne pas changer de mot de passe.</p>
        <div class="form-group">
            <label>Nouveau mot de passe</label>
            <input type="password" name="nouveau_mdp" autocomplete="new-password">
        </div>
        <div class="form-group">
            <label>Confirmer le nouveau mot de passe</label>
            <input type="password" name="confirm_mdp" autocomplete="new-password">
        </div>
        <hr style="margin:1.2rem 0;border:none;border-top:1px solid var(--gray-200);">
        <div class="form-group">
            <label>Mot de passe actuel <span style="color:var(--error)">*</span></label>
            <input type="password" name="mdp_actuel" required autocomplete="current-password">
            <small class="text-muted">Requis pour valider les modifications</small>
        </div>
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Enregistrer</button>
            <a href="<?= BASE_URL ?>/profil/index" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>
