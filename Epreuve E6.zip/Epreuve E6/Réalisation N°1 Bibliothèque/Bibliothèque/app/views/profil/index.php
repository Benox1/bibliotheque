<?php // app/views/profil/index.php ?>
<h1 class="page-title">Mon profil</h1>

<div class="card" style="max-width:600px;">
    <table style="width:100%;box-shadow:none;background:transparent;">
        <tr><th style="padding:.5rem 1rem .5rem 0;background:transparent;color:var(--gray-600);width:160px;">Nom</th>
            <td style="background:transparent;"><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></td></tr>
        <tr><th style="padding:.5rem 1rem .5rem 0;background:transparent;color:var(--gray-600);">E-mail</th>
            <td style="background:transparent;"><?= htmlspecialchars($user['email']) ?></td></tr>
        <tr><th style="padding:.5rem 1rem .5rem 0;background:transparent;color:var(--gray-600);">Téléphone</th>
            <td style="background:transparent;"><?= htmlspecialchars($user['telephone'] ?? '—') ?></td></tr>
        <tr><th style="padding:.5rem 1rem .5rem 0;background:transparent;color:var(--gray-600);">Adresse</th>
            <td style="background:transparent;"><?= htmlspecialchars($user['adresse'] ?? '—') ?></td></tr>
        <tr><th style="padding:.5rem 1rem .5rem 0;background:transparent;color:var(--gray-600);">Inscription</th>
            <td style="background:transparent;"><?= $user['date_inscription'] ?></td></tr>
        <tr><th style="padding:.5rem 1rem .5rem 0;background:transparent;color:var(--gray-600);">Rôle</th>
            <td style="background:transparent;"><span class="badge badge-primary"><?= ucfirst($user['libelle_role']) ?></span></td></tr>
    </table>
    <div class="d-flex gap-2 mt-2">
        <a href="<?= BASE_URL ?>/profil/modifier" class="btn btn-primary">Modifier mon profil</a>
        <a href="<?= BASE_URL ?>/emprunts/index" class="btn btn-secondary">Mes emprunts</a>
    </div>
</div>
