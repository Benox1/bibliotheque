<?php // app/views/catalogue/show.php ?>
<a href="<?= BASE_URL ?>/catalogue/index" class="btn btn-secondary btn-sm mb-3">← Retour au catalogue</a>

<div class="card">
    <h1 class="page-title"><?= htmlspecialchars($livre['titre']) ?></h1>
    <table style="width:auto;box-shadow:none;background:transparent;">
        <tr><th style="padding:.4rem 1rem .4rem 0;background:transparent;color:var(--gray-600);font-weight:600;">Auteur</th>
            <td style="padding:.4rem 0;background:transparent;"><?= htmlspecialchars($livre['nom_auteur']) ?></td></tr>
        <tr><th style="padding:.4rem 1rem .4rem 0;background:transparent;color:var(--gray-600);font-weight:600;">ISBN</th>
            <td style="padding:.4rem 0;background:transparent;"><?= htmlspecialchars($livre['isbn']) ?></td></tr>
        <?php if ($livre['annee_publication']): ?>
        <tr><th style="padding:.4rem 1rem .4rem 0;background:transparent;color:var(--gray-600);font-weight:600;">Année</th>
            <td style="padding:.4rem 0;background:transparent;"><?= $livre['annee_publication'] ?></td></tr>
        <?php endif; ?>
        <?php if ($livre['editeur']): ?>
        <tr><th style="padding:.4rem 1rem .4rem 0;background:transparent;color:var(--gray-600);font-weight:600;">Éditeur</th>
            <td style="padding:.4rem 0;background:transparent;"><?= htmlspecialchars($livre['editeur']) ?></td></tr>
        <?php endif; ?>
        <tr><th style="padding:.4rem 1rem .4rem 0;background:transparent;color:var(--gray-600);font-weight:600;">Disponibilité</th>
            <td style="padding:.4rem 0;background:transparent;">
                <span class="dispo <?= $livre['nb_exemplaires_dispo'] > 0 ? 'dispo-yes' : 'dispo-no' ?>">
                    <?= $livre['nb_exemplaires_dispo'] ?> / <?= $livre['nb_exemplaires_total'] ?> exemplaire(s) disponible(s)
                </span>
            </td></tr>
    </table>

    <?php if ($livre['resume']): ?>
        <p style="margin-top:1rem;line-height:1.6;"><?= nl2br(htmlspecialchars($livre['resume'])) ?></p>
    <?php endif; ?>

    <div class="d-flex gap-2 mt-2 flex-wrap">
        <?php if (!empty($_SESSION['user']) && $_SESSION['user']['role'] === 'adherent' && $livre['nb_exemplaires_dispo'] > 0): ?>
            <a href="<?= BASE_URL ?>/emprunts/emprunter/<?= $livre['id_livre'] ?>" class="btn btn-primary">Emprunter ce livre</a>
        <?php elseif (!empty($_SESSION['user']) && $_SESSION['user']['role'] === 'adherent'): ?>
            <span class="badge badge-danger">Indisponible actuellement</span>
        <?php elseif (empty($_SESSION['user'])): ?>
            <a href="<?= BASE_URL ?>/auth/login" class="btn btn-primary">Se connecter pour emprunter</a>
        <?php endif; ?>
    </div>
</div>
