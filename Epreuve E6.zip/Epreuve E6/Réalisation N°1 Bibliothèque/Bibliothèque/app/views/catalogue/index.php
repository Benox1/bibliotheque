<?php // app/views/catalogue/index.php ?>
<div class="d-flex justify-between align-items-center flex-wrap mb-3">
    <h1 class="page-title" style="margin-bottom:0;">Catalogue de livres</h1>
    <span class="text-muted"><?= count($livres) ?> livre(s) trouvé(s)</span>
</div>

<form method="GET" action="<?= BASE_URL ?>/catalogue/index" class="search-form">
    <input type="text" name="search" placeholder="Rechercher par titre ou ISBN…"
           value="<?= htmlspecialchars($search) ?>">
    <input type="text" name="auteur" placeholder="Filtrer par auteur…"
           value="<?= htmlspecialchars($auteur) ?>">
    <button type="submit" class="btn btn-primary">Rechercher</button>
    <?php if ($search || $auteur): ?>
        <a href="<?= BASE_URL ?>/catalogue/index" class="btn btn-secondary">Réinitialiser</a>
    <?php endif; ?>
</form>

<?php if (empty($livres)): ?>
    <div class="card" style="text-align:center;color:var(--gray-600);">
        <p>Aucun livre trouvé. Essayez d'autres mots-clés.</p>
    </div>
<?php else: ?>
<div class="livres-grid">
    <?php foreach ($livres as $livre): ?>
    <div class="livre-card">
        <h3><?= htmlspecialchars($livre['titre']) ?></h3>
        <p class="auteur">✍ <?= htmlspecialchars($livre['nom_auteur']) ?></p>
        <?php if ($livre['annee_publication']): ?>
            <p class="text-muted"><?= $livre['annee_publication'] ?></p>
        <?php endif; ?>
        <p class="dispo <?= $livre['nb_exemplaires_dispo'] > 0 ? 'dispo-yes' : 'dispo-no' ?>">
            <?= $livre['nb_exemplaires_dispo'] > 0
                ? "✔ {$livre['nb_exemplaires_dispo']} exemplaire(s) disponible(s)"
                : '✖ Indisponible' ?>
        </p>
        <div class="d-flex gap-2 flex-wrap mt-2">
            <a href="<?= BASE_URL ?>/catalogue/show/<?= $livre['id_livre'] ?>" class="btn btn-secondary btn-sm">Détails</a>
            <?php if (!empty($_SESSION['user']) && $_SESSION['user']['role'] === 'adherent' && $livre['nb_exemplaires_dispo'] > 0): ?>
                <a href="<?= BASE_URL ?>/emprunts/emprunter/<?= $livre['id_livre'] ?>" class="btn btn-primary btn-sm">Emprunter</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
