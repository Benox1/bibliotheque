<?php // app/views/auth/login.php ?>
<h1 class="page-title">Connexion</h1>

<?php if (!empty($errors)): ?>
<ul class="errors-list">
    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
</ul>
<?php endif; ?>

<div class="card" style="max-width:420px;margin:0 auto;">
    <form method="POST" action="<?= BASE_URL ?>/auth/login">
        <div class="form-group">
            <label for="email">Adresse e-mail</label>
            <input type="email" id="email" name="email" required autofocus
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label for="mot_de_passe">Mot de passe</label>
            <input type="password" id="mot_de_passe" name="mot_de_passe" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Se connecter</button>
    </form>
    <p class="text-muted mt-2" style="text-align:center;">
        Pas encore de compte ? <a href="<?= BASE_URL ?>/auth/register">Créer un compte</a>
    </p>
</div>
