<?php // app/views/auth/register.php ?>
<h1 class="page-title">Créer un compte</h1>

<?php if (!empty($errors)): ?>
<ul class="errors-list">
    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
</ul>
<?php endif; ?>

<div class="card" style="max-width:500px;margin:0 auto;">
    <form method="POST" action="<?= BASE_URL ?>/auth/register">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div class="form-group">
                <label>Nom</label>
                <input type="text" name="nom" required value="<?= htmlspecialchars($old['nom'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Prénom</label>
                <input type="text" name="prenom" required value="<?= htmlspecialchars($old['prenom'] ?? '') ?>">
            </div>
        </div>
        <div class="form-group">
            <label>Adresse e-mail</label>
            <input type="email" name="email" required value="<?= htmlspecialchars($old['email'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Téléphone</label>
            <input type="tel" name="telephone" value="<?= htmlspecialchars($old['telephone'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Adresse postale</label>
            <input type="text" name="adresse" value="<?= htmlspecialchars($old['adresse'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Mot de passe</label>
            <input type="password" name="mot_de_passe" required>
            <small class="text-muted">8 caractères min., 1 majuscule, 1 chiffre, 1 caractère spécial</small>
        </div>
        <div class="form-group">
            <label>Confirmer le mot de passe</label>
            <input type="password" name="confirm_mdp" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Créer mon compte</button>
    </form>
    <p class="text-muted mt-2" style="text-align:center;">
        Déjà inscrit ? <a href="<?= BASE_URL ?>/auth/login">Se connecter</a>
    </p>
</div>
