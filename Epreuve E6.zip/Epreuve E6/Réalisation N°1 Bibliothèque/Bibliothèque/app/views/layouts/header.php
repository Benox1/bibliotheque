<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bibliothèque</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Lora:ital,wght@0,400;0,500;1,400&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
</head>
<body>

<nav class="navbar">
    <a class="navbar-brand" href="<?= BASE_URL ?>/catalogue/index">📚 Bibliothèque</a>
    <ul class="navbar-nav">
        <li><a href="<?= BASE_URL ?>/catalogue/index">Catalogue</a></li>
        <?php if (!empty($_SESSION['user'])): ?>
            <li><a href="<?= BASE_URL ?>/emprunts/index"><?= $_SESSION['user']['role'] === 'administrateur' ? 'Tous les emprunts' : 'Mes emprunts' ?></a></li>
            <li><a href="<?= BASE_URL ?>/profil/index">Mon profil</a></li>
            <?php if ($_SESSION['user']['role'] === 'administrateur'): ?>
                <li><a href="<?= BASE_URL ?>/admin/dashboard">Administration</a></li>
            <?php endif; ?>
            <li><a href="<?= BASE_URL ?>/auth/logout" class="btn-link">Déconnexion</a></li>
        <?php else: ?>
            <li><a href="<?= BASE_URL ?>/auth/login">Connexion</a></li>
            <li><a href="<?= BASE_URL ?>/auth/register">Créer un compte</a></li>
        <?php endif; ?>
    </ul>
</nav>

<main class="container">
<?php if (!empty($_SESSION['flash'])): ?>
    <div class="alert alert-<?= htmlspecialchars($_SESSION['flash']['type']) ?>">
        <?= htmlspecialchars($_SESSION['flash']['message']) ?>
    </div>
    <?php unset($_SESSION['flash']); ?>
<?php endif; ?>
