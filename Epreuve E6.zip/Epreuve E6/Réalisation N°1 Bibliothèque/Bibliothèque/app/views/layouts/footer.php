</main>

<footer>
    <p>Bibliothèque &mdash; BTS SIO Épreuve E6 &mdash; Benoit DUFOUR</p>
</footer>

</body>
</html>
