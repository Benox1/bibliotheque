<?php // app/views/admin/supprimer_livre.php ?>
<h1 class="page-title">Supprimer un livre</h1>

<div class="card" style="max-width:500px;border-top:4px solid var(--error);">
    <p style="font-size:1.1rem;margin-bottom:1rem;">
        Êtes-vous sûr de vouloir supprimer le livre <strong>«&nbsp;<?= htmlspecialchars($livre['titre']) ?>&nbsp;»</strong> ?
    </p>
    <p class="text-muted" style="background:var(--error-bg);padding:.75rem;border-radius:var(--radius);color:var(--error);margin-bottom:1.2rem;">
        ⚠ Cette action est <strong>irréversible</strong>. Tous les exemplaires seront supprimés.
    </p>
    <form method="POST" action="<?= BASE_URL ?>/admin/supprimerLivre/<?= $livre['id_livre'] ?>">
        <input type="hidden" name="confirm" value="oui">
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-danger">Confirmer la suppression</button>
            <a href="<?= BASE_URL ?>/admin/livres" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>
