<?php // app/views/admin/adherents.php ?>
<h1 class="page-title">Gestion des adhérents</h1>

<div class="table-wrap">
<table>
    <thead>
        <tr><th>#</th><th>Nom</th><th>E-mail</th><th>Téléphone</th><th>Inscription</th><th>Emprunts en cours</th><th>Actions</th></tr>
    </thead>
    <tbody>
    <?php foreach ($adherents as $u): ?>
    <tr>
        <td><?= $u['id_utilisateur'] ?></td>
        <td><?= htmlspecialchars($u['prenom'] . ' ' . $u['nom']) ?></td>
        <td><?= htmlspecialchars($u['email']) ?></td>
        <td><?= htmlspecialchars($u['telephone'] ?? '—') ?></td>
        <td><?= $u['date_inscription'] ?></td>
        <td>
            <span class="badge <?= $u['nb_emprunts'] > 0 ? 'badge-warning' : 'badge-success' ?>">
                <?= $u['nb_emprunts'] ?>
            </span>
        </td>
        <td>
            <?php if ($u['nb_emprunts'] == 0): ?>
                <a href="<?= BASE_URL ?>/admin/supprimerCompte/<?= $u['id_utilisateur'] ?>" class="btn btn-danger btn-sm">Supprimer</a>
            <?php else: ?>
                <span class="text-muted" title="Emprunts en cours">🔒 Non supprimable</span>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>
