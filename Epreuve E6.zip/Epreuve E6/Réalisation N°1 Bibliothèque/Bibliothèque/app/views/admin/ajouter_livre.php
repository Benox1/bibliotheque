<?php // app/views/admin/ajouter_livre.php ?>
<h1 class="page-title">Ajouter un livre</h1>

<?php if (!empty($errors)): ?>
<ul class="errors-list">
    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
</ul>
<?php endif; ?>

<div class="card" style="max-width:600px;">
    <form method="POST" action="<?= BASE_URL ?>/admin/ajouterLivre">
        <div class="form-group">
            <label>Titre <span style="color:var(--error)">*</span></label>
            <input type="text" name="titre" required value="<?= htmlspecialchars($old['titre'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>ISBN (ISBN-10 ou ISBN-13) <span style="color:var(--error)">*</span></label>
            <input type="text" name="isbn" required value="<?= htmlspecialchars($old['isbn'] ?? '') ?>" placeholder="Ex : 9782070612758">
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div class="form-group">
                <label>Année de publication</label>
                <input type="number" name="annee_publication" min="1000" max="<?= date('Y') ?>"
                       value="<?= htmlspecialchars($old['annee_publication'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Nombre d'exemplaires <span style="color:var(--error)">*</span></label>
                <input type="number" name="nb_exemplaires_total" required min="1"
                       value="<?= htmlspecialchars($old['nb_exemplaires_total'] ?? '1') ?>">
            </div>
        </div>
        <div class="form-group">
            <label>Éditeur</label>
            <input type="text" name="editeur" value="<?= htmlspecialchars($old['editeur'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Auteur existant</label>
            <select name="id_auteur">
                <option value="0">— Sélectionner un auteur ou créer ci-dessous —</option>
                <?php foreach ($auteurs as $a): ?>
                    <option value="<?= $a['id_auteur'] ?>"
                        <?= ($old['id_auteur'] ?? '') == $a['id_auteur'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($a['nom']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Ou créer un nouvel auteur</label>
            <input type="text" name="new_auteur" placeholder="Nom complet de l'auteur"
                   value="<?= htmlspecialchars($old['new_auteur'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Résumé</label>
            <textarea name="resume" rows="4"><?= htmlspecialchars($old['resume'] ?? '') ?></textarea>
        </div>
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Ajouter le livre</button>
            <a href="<?= BASE_URL ?>/admin/livres" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>
