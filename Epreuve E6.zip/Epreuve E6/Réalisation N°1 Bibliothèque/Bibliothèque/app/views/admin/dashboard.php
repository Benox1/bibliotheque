<?php // app/views/admin/dashboard.php ?>
<h1 class="page-title">Tableau de bord Administration</h1>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value"><?= $stats['livres'] ?></div>
        <div class="stat-label">📚 Livres au catalogue</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= $stats['adherents'] ?></div>
        <div class="stat-label">👤 Adhérents</div>
    </div>
    <div class="stat-card" style="border-top-color:#38a169;">
        <div class="stat-value" style="color:#38a169;"><?= $stats['emprunts_en_cours'] ?></div>
        <div class="stat-label">📖 Emprunts en cours</div>
    </div>
    <div class="stat-card" style="border-top-color:var(--error);">
        <div class="stat-value" style="color:var(--error);"><?= $stats['emprunts_retard'] ?></div>
        <div class="stat-label">⚠ Emprunts en retard</div>
    </div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:1rem;">
    <a href="<?= BASE_URL ?>/admin/livres" class="card" style="text-decoration:none;text-align:center;">
        <div style="font-size:2.5rem;">📚</div>
        <p style="font-weight:700;color:var(--primary);margin-top:.5rem;">Gérer les livres</p>
    </a>
    <a href="<?= BASE_URL ?>/admin/adherents" class="card" style="text-decoration:none;text-align:center;">
        <div style="font-size:2.5rem;">👥</div>
        <p style="font-weight:700;color:var(--primary);margin-top:.5rem;">Gérer les adhérents</p>
    </a>
    <a href="<?= BASE_URL ?>/emprunts/index" class="card" style="text-decoration:none;text-align:center;">
        <div style="font-size:2.5rem;">📋</div>
        <p style="font-weight:700;color:var(--primary);margin-top:.5rem;">Tous les emprunts</p>
    </a>
    <a href="<?= BASE_URL ?>/catalogue/index" class="card" style="text-decoration:none;text-align:center;">
        <div style="font-size:2.5rem;">🔍</div>
        <p style="font-weight:700;color:var(--primary);margin-top:.5rem;">Consulter le catalogue</p>
    </a>
</div>
