<?php // app/views/admin/supprimer_compte.php ?>
<h1 class="page-title">Supprimer un compte adhérent</h1>

<div class="card" style="max-width:500px;border-top:4px solid var(--error);">
    <p style="font-size:1.1rem;margin-bottom:1rem;">
        Êtes-vous sûr de vouloir supprimer le compte de
        <strong>«&nbsp;<?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?>&nbsp;»</strong> ?
    </p>
    <table style="width:100%;box-shadow:none;background:transparent;margin-bottom:1rem;">
        <tr><th style="background:transparent;color:var(--gray-600);padding:.3rem 1rem .3rem 0;">E-mail</th>
            <td style="background:transparent;"><?= htmlspecialchars($user['email']) ?></td></tr>
        <tr><th style="background:transparent;color:var(--gray-600);padding:.3rem 1rem .3rem 0;">Inscription</th>
            <td style="background:transparent;"><?= $user['date_inscription'] ?></td></tr>
    </table>
    <p class="text-muted" style="background:var(--error-bg);padding:.75rem;border-radius:var(--radius);color:var(--error);margin-bottom:1.2rem;">
        ⚠ Le compte sera supprimé et les données personnelles anonymisées (RGPD). Action <strong>irréversible</strong>.
    </p>
    <form method="POST" action="<?= BASE_URL ?>/admin/supprimerCompte/<?= $user['id_utilisateur'] ?>">
        <input type="hidden" name="confirm" value="oui">
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-danger">Confirmer la suppression</button>
            <a href="<?= BASE_URL ?>/admin/adherents" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>
