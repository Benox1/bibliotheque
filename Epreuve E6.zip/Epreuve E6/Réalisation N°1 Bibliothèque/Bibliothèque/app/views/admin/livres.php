<?php // app/views/admin/livres.php ?>
<div class="d-flex justify-between align-items-center flex-wrap mb-3">
    <h1 class="page-title" style="margin-bottom:0;">Gestion des livres</h1>
    <a href="<?= BASE_URL ?>/admin/ajouterLivre" class="btn btn-primary">+ Ajouter un livre</a>
</div>

<div class="table-wrap">
<table>
    <thead>
        <tr><th>Titre</th><th>Auteur</th><th>ISBN</th><th>Total</th><th>Dispo</th><th>Ajouté le</th><th>Actions</th></tr>
    </thead>
    <tbody>
    <?php foreach ($livres as $l): ?>
    <tr>
        <td><?= htmlspecialchars($l['titre']) ?></td>
        <td><?= htmlspecialchars($l['nom_auteur']) ?></td>
        <td><code><?= htmlspecialchars($l['isbn']) ?></code></td>
        <td><?= $l['nb_exemplaires_total'] ?></td>
        <td>
            <span class="badge <?= $l['nb_exemplaires_dispo'] > 0 ? 'badge-success' : 'badge-danger' ?>">
                <?= $l['nb_exemplaires_dispo'] ?>
            </span>
        </td>
        <td><?= $l['date_ajout'] ?></td>
        <td>
            <a href="<?= BASE_URL ?>/admin/supprimerLivre/<?= $l['id_livre'] ?>" class="btn btn-danger btn-sm">Supprimer</a>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>
