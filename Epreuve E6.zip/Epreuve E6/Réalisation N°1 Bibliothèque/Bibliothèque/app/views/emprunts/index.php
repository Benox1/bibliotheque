<?php // app/views/emprunts/index.php
$isAdmin = ($_SESSION['user']['role'] === 'administrateur');
?>
<div class="d-flex justify-between align-items-center flex-wrap mb-3">
    <h1 class="page-title" style="margin-bottom:0;">
        <?= $isAdmin ? 'Tous les emprunts' : 'Mes emprunts' ?>
    </h1>
    <span class="text-muted"><?= $total ?> emprunt(s)</span>
</div>

<form method="GET" action="<?= BASE_URL ?>/emprunts/index" class="search-form">
    <select name="statut">
        <option value="">Tous les statuts</option>
        <option value="en_cours"  <?= $statut === 'en_cours'  ? 'selected' : '' ?>>En cours</option>
        <option value="retourne"  <?= $statut === 'retourne'  ? 'selected' : '' ?>>Retournés</option>
        <option value="en_retard" <?= $statut === 'en_retard' ? 'selected' : '' ?>>En retard</option>
    </select>
    <?php if ($isAdmin): ?>
        <input type="text" name="search" placeholder="Rechercher adhérent ou livre…"
               value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Filtrer</button>
    <a href="<?= BASE_URL ?>/emprunts/index" class="btn btn-secondary">Réinitialiser</a>
</form>

<?php if (empty($emprunts)): ?>
    <div class="card" style="text-align:center;color:var(--gray-600);">
        <p>Aucun emprunt enregistré.</p>
    </div>
<?php else: ?>
<div class="table-wrap">
<table>
    <thead>
        <tr>
            <th>#</th>
            <?php if ($isAdmin): ?><th>Adhérent</th><?php endif; ?>
            <th>Livre</th>
            <th>Emprunté le</th>
            <th>Retour prévu</th>
            <th>Retour effectif</th>
            <th>Statut</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($emprunts as $e):
        $retard = ($e['statut'] === 'en_retard' || ($e['statut'] === 'en_cours' && $e['date_retour_prevue'] < date('Y-m-d')));
        $rowStyle = $retard ? 'style="background:#fff5f5;"' : '';
    ?>
    <tr <?= $rowStyle ?>>
        <td><?= $e['id_emprunt'] ?></td>
        <?php if ($isAdmin): ?>
        <td><?= htmlspecialchars($e['adherent_prenom'] . ' ' . $e['adherent_nom']) ?></td>
        <?php endif; ?>
        <td><?= htmlspecialchars($e['titre']) ?></td>
        <td><?= $e['date_emprunt'] ?></td>
        <td><?= $retard && $e['statut'] !== 'retourne' ? '<strong style="color:var(--error)">' . $e['date_retour_prevue'] . '</strong>' : $e['date_retour_prevue'] ?></td>
        <td><?= $e['date_retour_effective'] ?? '—' ?></td>
        <td>
            <?php
            $badges = ['en_cours'=>'badge-primary','retourne'=>'badge-success','en_retard'=>'badge-danger'];
            $labels = ['en_cours'=>'En cours','retourne'=>'Retourné','en_retard'=>'En retard'];
            $s = $retard && $e['statut'] === 'en_cours' ? 'en_retard' : $e['statut'];
            ?>
            <span class="badge <?= $badges[$s] ?? 'badge-primary' ?>"><?= $labels[$s] ?? $s ?></span>
        </td>
        <td>
            <div class="d-flex gap-2 flex-wrap">
            <?php if ($e['statut'] === 'en_cours'): ?>
                <a href="<?= BASE_URL ?>/emprunts/retourner/<?= $e['id_emprunt'] ?>"
                   class="btn btn-success btn-sm"
                   onclick="return confirm('Confirmer le retour de ce livre ?')">Retourner</a>
                <?php if (empty($e['id_prolongation']) && !$retard): ?>
                    <a href="<?= BASE_URL ?>/emprunts/prolonger/<?= $e['id_emprunt'] ?>"
                       class="btn btn-warning btn-sm"
                       onclick="return confirm('Prolonger cet emprunt de 10 jours ?')">Prolonger</a>
                <?php endif; ?>
            <?php else: ?>
                <span class="text-muted">—</span>
            <?php endif; ?>
            </div>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>

<?php if ($pages > 1): ?>
<div class="pagination">
    <?php for ($i = 1; $i <= $pages; $i++):
        $params = array_merge($_GET, ['page' => $i]);
        $qs = http_build_query($params);
    ?>
        <?php if ($i === $page): ?>
            <span class="active"><?= $i ?></span>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/emprunts/index?<?= $qs ?>"><?= $i ?></a>
        <?php endif; ?>
    <?php endfor; ?>
</div>
<?php endif; ?>
<?php endif; ?>
