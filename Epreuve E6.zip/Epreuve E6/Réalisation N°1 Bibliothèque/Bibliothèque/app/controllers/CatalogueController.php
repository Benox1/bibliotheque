<?php
require_once ROOT . '/app/controllers/Controller.php';
require_once ROOT . '/app/models/LivreModel.php';

class CatalogueController extends Controller {

    private LivreModel $model;

    public function __construct() {
        $this->model = new LivreModel();
    }

    public function index(): void {
        $search = trim($_GET['search'] ?? '');
        $auteur = trim($_GET['auteur'] ?? '');
        $livres = $this->model->search($search, $auteur);
        $this->view('catalogue/index', compact('livres', 'search', 'auteur'));
    }

    public function show(?string $id): void {
        if (!$id) $this->redirect('catalogue/index');
        $livre = $this->model->findById((int)$id);
        if (!$livre) {
            $this->flash('error', 'Livre introuvable.');
            $this->redirect('catalogue/index');
        }
        $this->view('catalogue/show', compact('livre'));
    }
}
