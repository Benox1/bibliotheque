<?php
require_once ROOT . '/app/controllers/Controller.php';
require_once ROOT . '/app/models/LivreModel.php';
require_once ROOT . '/app/models/AuteurModel.php';
require_once ROOT . '/app/models/UtilisateurModel.php';
require_once ROOT . '/app/models/EmpruntModel.php';
require_once ROOT . '/app/models/AuditModel.php';

class AdminController extends Controller {

    private LivreModel       $livreModel;
    private AuteurModel      $auteurModel;
    private UtilisateurModel $userModel;
    private EmpruntModel     $empruntModel;
    private AuditModel       $auditModel;

    public function __construct() {
        $this->livreModel   = new LivreModel();
        $this->auteurModel  = new AuteurModel();
        $this->userModel    = new UtilisateurModel();
        $this->empruntModel = new EmpruntModel();
        $this->auditModel   = new AuditModel();
    }

    // ── Dashboard ──────────────────────────────────────────
    public function dashboard(): void {
        $this->requireAdmin();
        $stats = [
            'livres'           => $this->livreModel->count(),
            'adherents'        => $this->userModel->countAdherents(),
            'emprunts_en_cours'=> $this->empruntModel->countEnCours(),
            'emprunts_retard'  => $this->empruntModel->countEnRetard(),
        ];
        $this->view('admin/dashboard', compact('stats'));
    }

    // ── Gestion des livres ─────────────────────────────────
    public function livres(): void {
        $this->requireAdmin();
        $livres = $this->livreModel->getAll();
        $this->view('admin/livres', compact('livres'));
    }

    public function ajouterLivre(): void {
        $this->requireAdmin();
        $errors  = [];
        $auteurs = $this->auteurModel->getAll();
        $old     = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $old = $_POST;
            $titre   = trim($_POST['titre']            ?? '');
            $isbn    = trim($_POST['isbn']             ?? '');
            $annee   = trim($_POST['annee_publication'] ?? '') ?: null;
            $editeur = trim($_POST['editeur']          ?? '') ?: null;
            $resume  = trim($_POST['resume']           ?? '') ?: null;
            $nbEx    = (int)($_POST['nb_exemplaires_total'] ?? 0);
            $idAuteur= (int)($_POST['id_auteur']       ?? 0);
            $newAuteur = trim($_POST['new_auteur']     ?? '');

            if (!$titre)  $errors[] = 'Le titre est obligatoire.';
            if (!$this->validateISBN($isbn)) $errors[] = 'Format ISBN invalide (ISBN-10 ou ISBN-13 requis).';
            if ($nbEx < 1) $errors[] = 'Le nombre d\'exemplaires doit être ≥ 1.';

            if (empty($errors)) {
                // Créer un nouvel auteur si besoin
                if ($idAuteur === 0 && $newAuteur !== '') {
                    $idAuteur = $this->auteurModel->create($newAuteur);
                } elseif ($idAuteur === 0) {
                    $errors[] = 'Sélectionnez ou créez un auteur.';
                }
            }

            if (empty($errors)) {
                if ($this->livreModel->isbnExists($isbn)) {
                    $errors[] = 'Un livre avec cet ISBN existe déjà.';
                } else {
                    $livreId = $this->livreModel->create($titre, $isbn, $annee, $editeur, $resume, $nbEx, $idAuteur);
                    // Créer les exemplaires
                    for ($i = 1; $i <= $nbEx; $i++) {
                        $codeBarre = 'EX' . str_pad($livreId, 3, '0', STR_PAD_LEFT) . chr(64 + $i);
                        $this->livreModel->createExemplaire($livreId, $codeBarre);
                    }
                    $this->auditModel->log('AJOUT_LIVRE', "Livre ajouté : $titre (ISBN: $isbn)", $_SESSION['user']['id']);
                    $this->flash('success', "Livre « $titre » ajouté avec $nbEx exemplaire(s).");
                    $this->redirect('admin/livres');
                }
            }
        }

        $this->view('admin/ajouter_livre', compact('errors', 'auteurs', 'old'));
    }

    public function supprimerLivre(?string $id): void {
        $this->requireAdmin();
        if (!$id) $this->redirect('admin/livres');

        $livre = $this->livreModel->findById((int)$id);
        if (!$livre) {
            $this->flash('error', 'Livre introuvable.');
            $this->redirect('admin/livres');
        }

        // RG-06 : impossible si exemplaires empruntés
        if ($this->livreModel->hasActiveEmprunts((int)$id)) {
            $this->flash('error', 'Impossible de supprimer : des exemplaires sont actuellement empruntés.');
            $this->redirect('admin/livres');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirm'] ?? '') === 'oui') {
            $this->livreModel->delete((int)$id);
            $this->auditModel->log('SUPPRESSION_LIVRE', "Livre supprimé : {$livre['titre']}", $_SESSION['user']['id']);
            $this->flash('success', "Livre « {$livre['titre']} » supprimé.");
            $this->redirect('admin/livres');
        }

        $this->view('admin/supprimer_livre', compact('livre'));
    }

    // ── Gestion des adhérents ──────────────────────────────
    public function adherents(): void {
        $this->requireAdmin();
        $adherents = $this->userModel->getAllAdherents();
        $this->view('admin/adherents', compact('adherents'));
    }

    public function supprimerCompte(?string $id): void {
        $this->requireAdmin();
        if (!$id) $this->redirect('admin/adherents');

        $user = $this->userModel->findById((int)$id);
        if (!$user) {
            $this->flash('error', 'Utilisateur introuvable.');
            $this->redirect('admin/adherents');
        }

        // RG-05 : impossible si emprunts en cours
        if ($this->empruntModel->countEnCoursByUser((int)$id) > 0) {
            $this->flash('error', 'Impossible : cet adhérent a des emprunts en cours.');
            $this->redirect('admin/adherents');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirm'] ?? '') === 'oui') {
            $this->userModel->delete((int)$id);
            $this->auditModel->log('SUPPRESSION_COMPTE', "Compte supprimé : {$user['email']}", $_SESSION['user']['id']);
            $this->flash('success', "Compte de {$user['prenom']} {$user['nom']} supprimé.");
            $this->redirect('admin/adherents');
        }

        $this->view('admin/supprimer_compte', compact('user'));
    }

    // ── Validation ISBN ────────────────────────────────────
    private function validateISBN(string $isbn): bool {
        $isbn = preg_replace('/[\s\-]/', '', $isbn);
        if (strlen($isbn) === 10) {
            $sum = 0;
            for ($i = 0; $i < 9; $i++) {
                if (!is_numeric($isbn[$i])) return false;
                $sum += (int)$isbn[$i] * (10 - $i);
            }
            $last = strtoupper($isbn[9]);
            $sum += ($last === 'X') ? 10 : (int)$last;
            return $sum % 11 === 0;
        }
        if (strlen($isbn) === 13) {
            $sum = 0;
            for ($i = 0; $i < 12; $i++) {
                if (!is_numeric($isbn[$i])) return false;
                $sum += (int)$isbn[$i] * ($i % 2 === 0 ? 1 : 3);
            }
            $check = (10 - ($sum % 10)) % 10;
            return $check === (int)$isbn[12];
        }
        return false;
    }
}
