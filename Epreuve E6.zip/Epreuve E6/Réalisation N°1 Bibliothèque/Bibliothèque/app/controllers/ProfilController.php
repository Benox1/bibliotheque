<?php
require_once ROOT . '/app/controllers/Controller.php';
require_once ROOT . '/app/models/UtilisateurModel.php';

class ProfilController extends Controller {

    private UtilisateurModel $model;

    public function __construct() {
        $this->model = new UtilisateurModel();
    }

    public function index(): void {
        $this->requireAuth();
        $user = $this->model->findById($_SESSION['user']['id']);
        $this->view('profil/index', compact('user'));
    }

    public function modifier(): void {
        $this->requireAuth();
        $errors = [];
        $userId = $_SESSION['user']['id'];
        $user   = $this->model->findById($userId);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email    = trim($_POST['email']     ?? '');
            $tel      = trim($_POST['telephone'] ?? '');
            $adresse  = trim($_POST['adresse']   ?? '');
            $mdpActuel = $_POST['mdp_actuel']    ?? '';
            $newMdp   = $_POST['nouveau_mdp']    ?? '';
            $confirm  = $_POST['confirm_mdp']    ?? '';

            // Vérification du mot de passe actuel pour données sensibles
            if (!password_verify($mdpActuel, $user['mot_de_passe'])) {
                $errors[] = 'Mot de passe actuel incorrect.';
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail invalide.';

            if ($email !== $user['email'] && $this->model->emailExistsExcept($email, $userId)) {
                $errors[] = 'Cet e-mail est déjà utilisé.';
            }

            $newHash = null;
            if ($newMdp !== '') {
                if (!preg_match('/^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $newMdp))
                    $errors[] = 'Le nouveau mot de passe ne respecte pas les critères de sécurité.';
                if ($newMdp !== $confirm) $errors[] = 'Les nouveaux mots de passe ne correspondent pas.';
                if (empty($errors)) $newHash = password_hash($newMdp, PASSWORD_BCRYPT);
            }

            if (empty($errors)) {
                $this->model->update($userId, $email, $tel, $adresse, $newHash);
                $_SESSION['user']['email'] = $email;
                $this->flash('success', 'Profil mis à jour avec succès.');
                $this->redirect('profil/index');
            }
        }

        $this->view('profil/modifier', compact('user', 'errors'));
    }
}
