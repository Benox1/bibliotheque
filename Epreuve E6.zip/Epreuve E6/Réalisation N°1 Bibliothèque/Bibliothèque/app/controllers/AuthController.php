<?php
require_once ROOT . '/app/controllers/Controller.php';
require_once ROOT . '/app/models/UtilisateurModel.php';

class AuthController extends Controller {

    private UtilisateurModel $model;

    public function __construct() {
        $this->model = new UtilisateurModel();
    }

    // ── Inscription ────────────────────────────────────────
    public function register(): void {
        if (!empty($_SESSION['user'])) $this->redirect('catalogue/index');

        $errors = [];
        $old    = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $old = $_POST;
            $nom      = trim($_POST['nom']      ?? '');
            $prenom   = trim($_POST['prenom']   ?? '');
            $email    = trim($_POST['email']    ?? '');
            $tel      = trim($_POST['telephone'] ?? '');
            $adresse  = trim($_POST['adresse']  ?? '');
            $mdp      = $_POST['mot_de_passe']  ?? '';
            $confirm  = $_POST['confirm_mdp']   ?? '';

            if (!$nom)    $errors[] = 'Le nom est obligatoire.';
            if (!$prenom) $errors[] = 'Le prénom est obligatoire.';
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail invalide.';
            if (!preg_match('/^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $mdp))
                $errors[] = 'Le mot de passe doit contenir au moins 8 caractères, 1 majuscule, 1 chiffre et 1 caractère spécial.';
            if ($mdp !== $confirm) $errors[] = 'Les mots de passe ne correspondent pas.';

            if (empty($errors)) {
                if ($this->model->emailExists($email)) {
                    $errors[] = 'Cet e-mail est déjà utilisé.';
                } else {
                    $hash = password_hash($mdp, PASSWORD_BCRYPT);
                    $this->model->create($nom, $prenom, $email, $hash, $tel, $adresse);
                    $this->flash('success', 'Compte créé ! Vous pouvez vous connecter.');
                    $this->redirect('auth/login');
                }
            }
        }

        $this->view('auth/register', compact('errors', 'old'));
    }

    // ── Connexion ──────────────────────────────────────────
    public function login(): void {
        if (!empty($_SESSION['user'])) $this->redirect('catalogue/index');

        $errors = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $mdp   = $_POST['mot_de_passe'] ?? '';

            // Gestion blocage après 3 tentatives
            if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = 0;
            if (!isset($_SESSION['login_blocked_until'])) $_SESSION['login_blocked_until'] = 0;

            if (time() < $_SESSION['login_blocked_until']) {
                $remaining = $_SESSION['login_blocked_until'] - time();
                $errors[] = "Compte temporairement bloqué. Réessayez dans $remaining secondes.";
            } else {
                $user = $this->model->findByEmail($email);
                if ($user && password_verify($mdp, $user['mot_de_passe'])) {
                    $_SESSION['login_attempts'] = 0;
                    $_SESSION['user'] = [
                        'id'     => $user['id_utilisateur'],
                        'nom'    => $user['nom'],
                        'prenom' => $user['prenom'],
                        'email'  => $user['email'],
                        'role'   => $user['libelle_role'],
                    ];
                    $this->redirect($user['libelle_role'] === 'administrateur' ? 'admin/dashboard' : 'catalogue/index');
                } else {
                    $_SESSION['login_attempts']++;
                    if ($_SESSION['login_attempts'] >= 3) {
                        $_SESSION['login_blocked_until'] = time() + 300; // 5 min
                        $_SESSION['login_attempts'] = 0;
                        $errors[] = 'Trop de tentatives. Compte bloqué 5 minutes.';
                    } else {
                        $errors[] = 'Identifiants incorrects.';
                    }
                }
            }
        }

        $this->view('auth/login', compact('errors'));
    }

    // ── Déconnexion ────────────────────────────────────────
    public function logout(): void {
        session_destroy();
        header('Location: ' . BASE_URL . '/auth/login');
        exit;
    }
}
