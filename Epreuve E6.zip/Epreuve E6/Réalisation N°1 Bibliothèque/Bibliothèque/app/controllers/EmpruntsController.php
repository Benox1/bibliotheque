<?php
require_once ROOT . '/app/controllers/Controller.php';
require_once ROOT . '/app/models/EmpruntModel.php';
require_once ROOT . '/app/models/LivreModel.php';

class EmpruntsController extends Controller {

    private EmpruntModel $model;
    private LivreModel   $livreModel;

    public function __construct() {
        $this->model      = new EmpruntModel();
        $this->livreModel = new LivreModel();
    }

    // ── Liste des emprunts ─────────────────────────────────
    public function index(): void {
        $this->requireAuth();
        $userId = $_SESSION['user']['id'];
        $role   = $_SESSION['user']['role'];

        $statut  = $_GET['statut'] ?? '';
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;
        $offset  = ($page - 1) * $perPage;

        if ($role === 'administrateur') {
            $search   = trim($_GET['search'] ?? '');
            $emprunts = $this->model->getAllPaginated($statut, $search, $perPage, $offset);
            $total    = $this->model->countAll($statut, $search);
        } else {
            $emprunts = $this->model->getByUserPaginated($userId, $statut, $perPage, $offset);
            $total    = $this->model->countByUser($userId, $statut);
        }

        $pages = (int) ceil($total / $perPage);
        $this->view('emprunts/index', compact('emprunts', 'statut', 'page', 'pages', 'total'));
    }

    // ── Emprunter un livre ─────────────────────────────────
    public function emprunter(?string $livreId): void {
        $this->requireAuth();
        if ($_SESSION['user']['role'] === 'administrateur') $this->redirect('catalogue/index');

        if (!$livreId) $this->redirect('catalogue/index');

        $userId = $_SESSION['user']['id'];
        $livre  = $this->livreModel->findById((int)$livreId);

        if (!$livre) {
            $this->flash('error', 'Livre introuvable.');
            $this->redirect('catalogue/index');
        }

        // Vérif quota (RG-01)
        if ($this->model->countEnCoursByUser($userId) >= 3) {
            $this->flash('error', 'Quota atteint : vous ne pouvez pas emprunter plus de 3 livres simultanément.');
            $this->redirect('catalogue/index');
        }

        // Vérif disponibilité (RG-04)
        $exemplaire = $this->livreModel->getExemplaireDisponible((int)$livreId);
        if (!$exemplaire) {
            $this->flash('error', 'Aucun exemplaire disponible pour ce livre.');
            $this->redirect('catalogue/index');
        }

        $dateEmprunt = date('Y-m-d');
        $dateRetour  = date('Y-m-d', strtotime('+20 days')); // RG-02

        $this->model->create($userId, $exemplaire['id_exemplaire'], $dateEmprunt, $dateRetour);
        $this->livreModel->setExemplaireDisponible($exemplaire['id_exemplaire'], false);
        $this->livreModel->updateDispoCount((int)$livreId);

        $this->flash('success', "Livre « {$livre['titre']} » emprunté jusqu'au $dateRetour.");
        $this->redirect('emprunts/index');
    }

    // ── Retourner un livre ─────────────────────────────────
    public function retourner(?string $empruntId): void {
        $this->requireAuth();
        if (!$empruntId) $this->redirect('emprunts/index');

        $userId  = $_SESSION['user']['id'];
        $emprunt = $this->model->findById((int)$empruntId);

        if (!$emprunt || ($emprunt['id_utilisateur'] != $userId && $_SESSION['user']['role'] !== 'administrateur')) {
            $this->flash('error', 'Emprunt introuvable ou accès non autorisé.');
            $this->redirect('emprunts/index');
        }

        if ($emprunt['statut'] === 'retourne') {
            $this->flash('error', 'Ce livre a déjà été retourné.');
            $this->redirect('emprunts/index');
        }

        $dateRetourEffective = date('Y-m-d');
        $this->model->retourner((int)$empruntId, $dateRetourEffective);
        $this->livreModel->setExemplaireDisponible($emprunt['id_exemplaire'], true);
        $this->livreModel->updateDispoCount($emprunt['id_livre']);

        $this->flash('success', 'Livre retourné avec succès.');
        $this->redirect('emprunts/index');
    }

    // ── Prolonger un emprunt (UC-11) ──────────────────────
    public function prolonger(?string $empruntId): void {
        $this->requireAuth();
        if (!$empruntId) $this->redirect('emprunts/index');

        $userId  = $_SESSION['user']['id'];
        $emprunt = $this->model->findById((int)$empruntId);

        if (!$emprunt || ($emprunt['id_utilisateur'] != $userId && $_SESSION['user']['role'] !== 'administrateur')) {
            $this->flash('error', 'Emprunt introuvable.');
            $this->redirect('emprunts/index');
        }

        if ($emprunt['statut'] !== 'en_cours') {
            $this->flash('error', 'Impossible de prolonger cet emprunt.');
            $this->redirect('emprunts/index');
        }

        if ($this->model->hasProlongation((int)$empruntId)) {
            $this->flash('error', 'Cet emprunt a déjà été prolongé (maximum 1 fois).');
            $this->redirect('emprunts/index');
        }

        $nouvelleDateRetour = date('Y-m-d', strtotime($emprunt['date_retour_prevue'] . ' +10 days'));
        $this->model->prolonger((int)$empruntId, $nouvelleDateRetour);

        $this->flash('success', "Emprunt prolongé. Nouvelle date de retour : $nouvelleDateRetour.");
        $this->redirect('emprunts/index');
    }
}
