<?php
// app/controllers/Controller.php
class Controller {

    protected function view(string $view, array $data = []): void {
        extract($data);
        $viewFile = ROOT . '/app/views/' . $view . '.php';
        if (!file_exists($viewFile)) {
            die("Vue introuvable : $view");
        }
        require ROOT . '/app/views/layouts/header.php';
        require $viewFile;
        require ROOT . '/app/views/layouts/footer.php';
    }

    protected function redirect(string $url): void {
        header('Location: ' . BASE_URL . '/' . $url);
        exit;
    }

    protected function requireAuth(): void {
        if (empty($_SESSION['user'])) {
            $this->redirect('auth/login');
        }
    }

    protected function requireAdmin(): void {
        $this->requireAuth();
        if ($_SESSION['user']['role'] !== 'administrateur') {
            $this->redirect('catalogue/index');
        }
    }

    protected function flash(string $type, string $message): void {
        $_SESSION['flash'] = ['type' => $type, 'message' => $message];
    }
}
