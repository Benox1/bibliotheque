<?php
// app/models/LivreModel.php
class LivreModel {
    private PDO $pdo;
    public function __construct() { $this->pdo = getPDO(); }

    public function search(string $search = '', string $auteur = ''): array {
        $sql = "SELECT l.*, a.nom AS nom_auteur FROM livre l JOIN auteur a ON l.id_auteur=a.id_auteur WHERE 1=1";
        $params = [];
        if ($search !== '') {
            $sql .= " AND (l.titre LIKE ? OR l.isbn LIKE ?)";
            $params[] = "%$search%"; $params[] = "%$search%";
        }
        if ($auteur !== '') {
            $sql .= " AND a.nom LIKE ?";
            $params[] = "%$auteur%";
        }
        $sql .= " ORDER BY l.titre";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getAll(): array {
        $stmt = $this->pdo->query("SELECT l.*, a.nom AS nom_auteur FROM livre l JOIN auteur a ON l.id_auteur=a.id_auteur ORDER BY l.titre");
        return $stmt->fetchAll();
    }

    public function findById(int $id): ?array {
        $stmt = $this->pdo->prepare("SELECT l.*, a.nom AS nom_auteur FROM livre l JOIN auteur a ON l.id_auteur=a.id_auteur WHERE l.id_livre=?");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function isbnExists(string $isbn): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM livre WHERE isbn=?");
        $stmt->execute([$isbn]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function create($titre,$isbn,$annee,$editeur,$resume,$nbEx,$idAuteur): int {
        $stmt = $this->pdo->prepare("INSERT INTO livre (titre,isbn,annee_publication,editeur,resume,nb_exemplaires_total,nb_exemplaires_dispo,id_auteur) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->execute([$titre,$isbn,$annee,$editeur,$resume,$nbEx,$nbEx,$idAuteur]);
        return (int)$this->pdo->lastInsertId();
    }

    public function createExemplaire(int $livreId, string $codeBarre): void {
        $stmt = $this->pdo->prepare("INSERT INTO exemplaire (id_livre,code_barre,est_disponible) VALUES (?,?,TRUE)");
        $stmt->execute([$livreId,$codeBarre]);
    }

    public function getExemplaireDisponible(int $livreId): ?array {
        $stmt = $this->pdo->prepare("SELECT * FROM exemplaire WHERE id_livre=? AND est_disponible=TRUE LIMIT 1");
        $stmt->execute([$livreId]);
        return $stmt->fetch() ?: null;
    }

    public function setExemplaireDisponible(int $exemplaireId, bool $dispo): void {
        $stmt = $this->pdo->prepare("UPDATE exemplaire SET est_disponible=? WHERE id_exemplaire=?");
        $stmt->execute([$dispo ? 1 : 0, $exemplaireId]);
    }

    public function updateDispoCount(int $livreId): void {
        $stmt = $this->pdo->prepare("UPDATE livre SET nb_exemplaires_dispo=(SELECT COUNT(*) FROM exemplaire WHERE id_livre=? AND est_disponible=TRUE) WHERE id_livre=?");
        $stmt->execute([$livreId,$livreId]);
    }

    public function hasActiveEmprunts(int $livreId): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM emprunt e JOIN exemplaire ex ON e.id_exemplaire=ex.id_exemplaire WHERE ex.id_livre=? AND e.statut='en_cours'");
        $stmt->execute([$livreId]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function delete(int $id): void {
        $this->pdo->prepare("DELETE FROM exemplaire WHERE id_livre=?")->execute([$id]);
        $this->pdo->prepare("DELETE FROM livre WHERE id_livre=?")->execute([$id]);
    }

    public function count(): int {
        return (int)$this->pdo->query("SELECT COUNT(*) FROM livre")->fetchColumn();
    }
}
