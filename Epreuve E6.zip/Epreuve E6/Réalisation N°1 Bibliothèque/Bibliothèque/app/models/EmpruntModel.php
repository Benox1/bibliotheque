<?php
// app/models/EmpruntModel.php
class EmpruntModel {
    private PDO $pdo;
    public function __construct() { $this->pdo = getPDO(); }

    public function create(int $userId, int $exemplaireId, string $dateEmprunt, string $dateRetour): int {
        $stmt = $this->pdo->prepare("INSERT INTO emprunt (id_utilisateur,id_exemplaire,date_emprunt,date_retour_prevue,statut) VALUES (?,?,?,?,'en_cours')");
        $stmt->execute([$userId,$exemplaireId,$dateEmprunt,$dateRetour]);
        return (int)$this->pdo->lastInsertId();
    }

    public function findById(int $id): ?array {
        $stmt = $this->pdo->prepare("
            SELECT e.*, l.titre, l.id_livre, ex.code_barre,
                   u.nom AS adherent_nom, u.prenom AS adherent_prenom,
                   p.id_prolongation
            FROM emprunt e
            JOIN exemplaire ex ON e.id_exemplaire=ex.id_exemplaire
            JOIN livre l ON ex.id_livre=l.id_livre
            JOIN utilisateur u ON e.id_utilisateur=u.id_utilisateur
            LEFT JOIN prolongation p ON e.id_emprunt=p.id_emprunt
            WHERE e.id_emprunt=?");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function getByUserPaginated(int $userId, string $statut, int $limit, int $offset): array {
        $sql = "SELECT e.*, l.titre, l.id_livre, p.id_prolongation
                FROM emprunt e
                JOIN exemplaire ex ON e.id_exemplaire=ex.id_exemplaire
                JOIN livre l ON ex.id_livre=l.id_livre
                LEFT JOIN prolongation p ON e.id_emprunt=p.id_emprunt
                WHERE e.id_utilisateur=?";
        $params = [$userId];
        if ($statut) { $sql .= " AND e.statut=?"; $params[] = $statut; }
        $sql .= " ORDER BY e.date_emprunt DESC LIMIT ? OFFSET ?";
        $params[] = $limit; $params[] = $offset;
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getAllPaginated(string $statut, string $search, int $limit, int $offset): array {
        $sql = "SELECT e.*, l.titre, l.id_livre, u.nom AS adherent_nom, u.prenom AS adherent_prenom, p.id_prolongation
                FROM emprunt e
                JOIN exemplaire ex ON e.id_exemplaire=ex.id_exemplaire
                JOIN livre l ON ex.id_livre=l.id_livre
                JOIN utilisateur u ON e.id_utilisateur=u.id_utilisateur
                LEFT JOIN prolongation p ON e.id_emprunt=p.id_emprunt WHERE 1=1";
        $params = [];
        if ($statut) { $sql .= " AND e.statut=?"; $params[] = $statut; }
        if ($search) { $sql .= " AND (l.titre LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }
        $sql .= " ORDER BY e.date_emprunt DESC LIMIT ? OFFSET ?";
        $params[] = $limit; $params[] = $offset;
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function countByUser(int $userId, string $statut): int {
        $sql = "SELECT COUNT(*) FROM emprunt WHERE id_utilisateur=?";
        $params = [$userId];
        if ($statut) { $sql .= " AND statut=?"; $params[] = $statut; }
        $stmt = $this->pdo->prepare($sql); $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    }

    public function countAll(string $statut, string $search): int {
        $sql = "SELECT COUNT(*) FROM emprunt e JOIN exemplaire ex ON e.id_exemplaire=ex.id_exemplaire JOIN livre l ON ex.id_livre=l.id_livre JOIN utilisateur u ON e.id_utilisateur=u.id_utilisateur WHERE 1=1";
        $params = [];
        if ($statut) { $sql .= " AND e.statut=?"; $params[] = $statut; }
        if ($search) { $sql .= " AND (l.titre LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }
        $stmt = $this->pdo->prepare($sql); $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    }

    public function countEnCoursByUser(int $userId): int {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM emprunt WHERE id_utilisateur=? AND statut='en_cours'");
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    }

    public function countEnCours(): int {
        return (int)$this->pdo->query("SELECT COUNT(*) FROM emprunt WHERE statut='en_cours'")->fetchColumn();
    }

    public function countEnRetard(): int {
        return (int)$this->pdo->query("SELECT COUNT(*) FROM emprunt WHERE statut='en_retard' OR (statut='en_cours' AND date_retour_prevue < CURDATE())")->fetchColumn();
    }

    public function retourner(int $id, string $date): void {
        $stmt = $this->pdo->prepare("UPDATE emprunt SET date_retour_effective=?,statut='retourne' WHERE id_emprunt=?");
        $stmt->execute([$date,$id]);
    }

    public function hasProlongation(int $empruntId): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM prolongation WHERE id_emprunt=?");
        $stmt->execute([$empruntId]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function prolonger(int $empruntId, string $nouvelleDateRetour): void {
        $stmt = $this->pdo->prepare("UPDATE emprunt SET date_retour_prevue=? WHERE id_emprunt=?");
        $stmt->execute([$nouvelleDateRetour,$empruntId]);
        $stmt = $this->pdo->prepare("INSERT INTO prolongation (id_emprunt,date_demande,nouvelle_date_retour,duree_prolongation) VALUES (?,CURDATE(),?,10)");
        $stmt->execute([$empruntId,$nouvelleDateRetour]);
    }

    // Met à jour automatiquement les statuts en retard
    public function updateStatuts(): void {
        $this->pdo->exec("UPDATE emprunt SET statut='en_retard' WHERE statut='en_cours' AND date_retour_prevue < CURDATE()");
    }
}
