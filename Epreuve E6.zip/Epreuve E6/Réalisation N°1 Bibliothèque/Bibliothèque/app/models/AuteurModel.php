<?php
// app/models/AuteurModel.php
class AuteurModel {
    private PDO $pdo;
    public function __construct() { $this->pdo = getPDO(); }

    public function getAll(): array {
        return $this->pdo->query("SELECT * FROM auteur ORDER BY nom")->fetchAll();
    }

    public function create(string $nom): int {
        $stmt = $this->pdo->prepare("INSERT INTO auteur (nom) VALUES (?)");
        $stmt->execute([$nom]);
        return (int)$this->pdo->lastInsertId();
    }
}
