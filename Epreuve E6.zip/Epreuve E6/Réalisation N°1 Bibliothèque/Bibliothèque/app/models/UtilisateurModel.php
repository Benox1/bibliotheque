<?php
// app/models/UtilisateurModel.php
class UtilisateurModel {
    private PDO $pdo;
    public function __construct() { $this->pdo = getPDO(); }

    public function create($nom,$prenom,$email,$hash,$tel,$adresse): int {
        $stmt = $this->pdo->prepare("
            INSERT INTO utilisateur (nom,prenom,email,mot_de_passe,telephone,adresse,id_role)
            VALUES (?,?,?,?,?,?,(SELECT id_role FROM role WHERE libelle_role='adherent'))");
        $stmt->execute([$nom,$prenom,$email,$hash,$tel,$adresse]);
        return (int)$this->pdo->lastInsertId();
    }

    public function findByEmail(string $email): ?array {
        $stmt = $this->pdo->prepare("
            SELECT u.*, r.libelle_role FROM utilisateur u
            JOIN role r ON u.id_role=r.id_role WHERE u.email=?");
        $stmt->execute([$email]);
        return $stmt->fetch() ?: null;
    }

    public function findById(int $id): ?array {
        $stmt = $this->pdo->prepare("
            SELECT u.*, r.libelle_role FROM utilisateur u
            JOIN role r ON u.id_role=r.id_role WHERE u.id_utilisateur=?");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function emailExists(string $email): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM utilisateur WHERE email=?");
        $stmt->execute([$email]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function emailExistsExcept(string $email, int $userId): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM utilisateur WHERE email=? AND id_utilisateur!=?");
        $stmt->execute([$email,$userId]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function update(int $id, string $email, string $tel, string $adresse, ?string $newHash): void {
        if ($newHash) {
            $stmt = $this->pdo->prepare("UPDATE utilisateur SET email=?,telephone=?,adresse=?,mot_de_passe=? WHERE id_utilisateur=?");
            $stmt->execute([$email,$tel,$adresse,$newHash,$id]);
        } else {
            $stmt = $this->pdo->prepare("UPDATE utilisateur SET email=?,telephone=?,adresse=? WHERE id_utilisateur=?");
            $stmt->execute([$email,$tel,$adresse,$id]);
        }
    }

    public function getAllAdherents(): array {
        $stmt = $this->pdo->query("
            SELECT u.*, r.libelle_role,
                   (SELECT COUNT(*) FROM emprunt e WHERE e.id_utilisateur=u.id_utilisateur AND e.statut='en_cours') AS nb_emprunts
            FROM utilisateur u JOIN role r ON u.id_role=r.id_role
            WHERE r.libelle_role='adherent' ORDER BY u.nom,u.prenom");
        return $stmt->fetchAll();
    }

    public function countAdherents(): int {
        return (int)$this->pdo->query("SELECT COUNT(*) FROM utilisateur u JOIN role r ON u.id_role=r.id_role WHERE r.libelle_role='adherent'")->fetchColumn();
    }

    public function delete(int $id): void {
        // Anonymisation RGPD avant suppression
        $stmt = $this->pdo->prepare("UPDATE utilisateur SET nom='[supprimé]',prenom='[supprimé]',email=CONCAT('deleted_',id_utilisateur,'@deleted.invalid'),telephone=NULL,adresse=NULL WHERE id_utilisateur=?");
        $stmt->execute([$id]);
        $stmt = $this->pdo->prepare("DELETE FROM utilisateur WHERE id_utilisateur=?");
        $stmt->execute([$id]);
    }
}
