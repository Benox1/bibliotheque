<?php
// app/models/AuditModel.php
class AuditModel {
    private PDO $pdo;
    public function __construct() { $this->pdo = getPDO(); }

    public function log(string $action, string $detail, ?int $auteurId): void {
        $stmt = $this->pdo->prepare("INSERT INTO audit_log (action,detail,id_auteur) VALUES (?,?,?)");
        $stmt->execute([$action, $detail, $auteurId]);
    }
}
