<?php
// public/index.php
session_start();

define('ROOT', dirname(__DIR__));
define('BASE_URL', '/bibliotheque/public');

require_once ROOT . '/config/database.php';

// Autoload simple
spl_autoload_register(function ($class) {
    $dirs = [ROOT . '/app/controllers/', ROOT . '/app/models/'];
    foreach ($dirs as $dir) {
        $file = $dir . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// ─── Routeur ───────────────────────────────────────────────
$uri    = $_GET['url'] ?? 'catalogue/index';
$parts  = explode('/', trim($uri, '/'));
$ctrl   = ucfirst($parts[0] ?? 'catalogue') . 'Controller';
$action = $parts[1] ?? 'index';
$param  = $parts[2] ?? null;

$controllerFile = ROOT . '/app/controllers/' . $ctrl . '.php';
if (!file_exists($controllerFile)) {
    http_response_code(404);
    die('<h1>404 – Page introuvable</h1>');
}

require_once $controllerFile;
$controller = new $ctrl();

if (!method_exists($controller, $action)) {
    http_response_code(404);
    die('<h1>404 – Action introuvable</h1>');
}

$controller->$action($param);
