-- ================================================
-- Bibliotheque - Insertions livres - Benoit DUFOUR
-- ISBN tous uniques, apostrophes sans probleme
-- ================================================

USE bibliotheque;

-- Nettoyage doublons auteurs eventuels
DELETE a1 FROM auteur a1 INNER JOIN auteur a2 WHERE a1.id_auteur > a2.id_auteur AND a1.nom = a2.nom;

-- Auteurs
INSERT IGNORE INTO auteur (nom) VALUES
  ('Victor Hugo'),
  ('Albert Camus'),
  ('J.K. Rowling'),
  ('George Orwell'),
  ('Antoine de Saint-Exupery'),
  ('Gustave Flaubert'),
  ('Emile Zola'),
  ('Marcel Proust'),
  ('Stendhal'),
  ('Honore de Balzac'),
  ('Alexandre Dumas'),
  ('Moliere'),
  ('Voltaire'),
  ('Jean-Paul Sartre'),
  ('Simone de Beauvoir'),
  ('Guy de Maupassant'),
  ('Jules Verne'),
  ('Stephen King'),
  ('Agatha Christie'),
  ('Arthur Conan Doyle'),
  ('Ernest Hemingway'),
  ('F. Scott Fitzgerald'),
  ('John Steinbeck'),
  ('Gabriel Garcia Marquez'),
  ('Franz Kafka'),
  ('Fiodor Dostoievski'),
  ('Leon Tolstoi'),
  ('J.R.R. Tolkien'),
  ('Isaac Asimov');

-- Variables auteurs
SET @hugo = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Victor Hugo');
SET @camus = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Albert Camus');
SET @rowling = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'J.K. Rowling');
SET @orwell = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'George Orwell');
SET @exupery = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Antoine de Saint-Exupery');
SET @flaubert = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Gustave Flaubert');
SET @zola = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Emile Zola');
SET @proust = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Marcel Proust');
SET @stendhal = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Stendhal');
SET @balzac = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Honore de Balzac');
SET @dumas = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Alexandre Dumas');
SET @moliere = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Moliere');
SET @voltaire = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Voltaire');
SET @sartre = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Jean-Paul Sartre');
SET @beauvoir = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Simone de Beauvoir');
SET @maupassant = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Guy de Maupassant');
SET @verne = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Jules Verne');
SET @king = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Stephen King');
SET @christie = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Agatha Christie');
SET @doyle = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Arthur Conan Doyle');
SET @hemingway = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Ernest Hemingway');
SET @fitzgerald = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'F. Scott Fitzgerald');
SET @steinbeck = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'John Steinbeck');
SET @marquez = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Gabriel Garcia Marquez');
SET @kafka = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Franz Kafka');
SET @dostoievski = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Fiodor Dostoievski');
SET @tolstoi = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Leon Tolstoi');
SET @tolkien = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'J.R.R. Tolkien');
SET @asimov = (SELECT MIN(id_auteur) FROM auteur WHERE nom = 'Isaac Asimov');

-- Livres
INSERT INTO livre (titre, isbn, annee_publication, editeur, resume, nb_exemplaires_total, nb_exemplaires_dispo, id_auteur) VALUES
('Les Miserables', '9782070409228', 1862, 'Gallimard', 'Jean Valjean, ancien forcat, cherche a se racheter dans une France marquee par la misere et l injustice.', 3, 3, @hugo),
('Notre-Dame de Paris', '9782070360024', 1831, 'Gallimard', 'Le bossu Quasimodo tombe amoureux de la belle gitane Esmeralda dans le Paris medieval.', 2, 2, @hugo),
('Les Contemplations', '9782070360161', 1856, 'Gallimard', 'Recueil poetique traverse par le deuil de la fille de l auteur, Leopoldine.', 2, 2, @hugo),
('L Homme qui rit', '9782070409570', 1869, 'Gallimard', 'Gwynplaine, defigure enfant, decouvre un jour qu il est pair d Angleterre.', 1, 1, @hugo),
('L Etranger', '9782070360413', 1942, 'Gallimard', 'Meursault commet un meurtre absurde et affronte un monde qui lui est etranger.', 3, 3, @camus),
('La Peste', '9782070360307', 1947, 'Gallimard', 'Dans la ville d Oran frappee par une epidemie, des hommes resistent a l absurde et a la mort.', 3, 3, @camus),
('Le Mythe de Sisyphe', '9782070322886', 1942, 'Gallimard', 'Essai philosophique sur la pensee de l absurde : pourquoi vivre dans un monde sans sens ?', 2, 2, @camus),
('La Chute', '9782070360901', 1956, 'Gallimard', 'Jean-Baptiste Clamence, ancien avocat, livre sa confession dans un bar d Amsterdam.', 2, 2, @camus),
('Harry Potter a l ecole des sorciers', '9782070541270', 1997, 'Gallimard', 'Harry decouvre le jour de ses 11 ans qu il est sorcier et entre a Poudlard.', 4, 4, @rowling),
('Harry Potter et la Chambre des secrets', '9782070541287', 1998, 'Gallimard', 'Une mysterieuse Chambre des secrets est rouverte a Poudlard, petrifiant plusieurs eleves.', 3, 3, @rowling),
('Harry Potter et le Prisonnier d Azkaban', '9782070541294', 1999, 'Gallimard', 'Sirius Black, dangereux sorcier, s est echappe de la prison magique d Azkaban.', 3, 3, @rowling),
('Harry Potter et la Coupe de feu', '9782070541300', 2000, 'Gallimard', 'Harry est mysterieusement inscrit au Tournoi des Trois Sorciers, une competition mortelle.', 2, 2, @rowling),
('1984', '9782070368228', 1949, 'Gallimard', 'Dans un etat totalitaire, Winston Smith tente de resister a Big Brother et a la pensee unique.', 3, 3, @orwell),
('La Ferme des animaux', '9782070360840', 1945, 'Gallimard', 'Des animaux renversent leur fermier pour instaurer une societe egalitaire qui degenere.', 3, 3, @orwell),
('Le Petit Prince', '9782070612758', 1943, 'Gallimard', 'Un aviateur tombe dans le desert rencontre un petit prince venu d une autre planete.', 4, 4, @exupery),
('Vol de nuit', '9782070360659', 1931, 'Gallimard', 'Les pilotes de l Aeropostale affrontent la nuit et les tempetes pour acheminer le courrier.', 2, 2, @exupery),
('Madame Bovary', '9782070413119', 1857, 'Gallimard', 'Emma Bovary reve d une vie romantique et s enlise dans l adultere et les dettes.', 3, 3, @flaubert),
('L Education sentimentale', '9782070413126', 1869, 'Gallimard', 'Frederic Moreau, jeune provincial ambitieux, s eprend d une femme mariee dans le Paris du Second Empire.', 2, 2, @flaubert),
('Germinal', '9782070413133', 1885, 'Gallimard', 'Etienne Lantier organise une greve desesperee dans les mines du Nord de la France.', 3, 3, @zola),
('L Assommoir', '9782070413140', 1877, 'Gallimard', 'Gervaise Macquart sombre dans l alcoolisme et la decheance dans les faubourgs pauvres de Paris.', 2, 2, @zola),
('Nana', '9782070413157', 1880, 'Gallimard', 'Nana, fille de Gervaise, devient une courtisane qui ruine les hommes de la haute societe.', 2, 2, @zola),
('Au Bonheur des Dames', '9782070413164', 1883, 'Gallimard', 'L essor d un grand magasin parisien ecrase les petits commercants du quartier.', 2, 2, @zola),
('Du cote de chez Swann', '9782070411542', 1913, 'Gallimard', 'Premier volume de la Recherche : la memoire involontaire et l amour de Swann pour Odette.', 2, 2, @proust),
('A l ombre des jeunes filles en fleurs', '9782070411559', 1919, 'Gallimard', 'Le narrateur decouvre Balbec et tombe amoureux d Albertine.', 1, 1, @proust),
('Le Rouge et le Noir', '9782070413003', 1830, 'Gallimard', 'Julien Sorel, fils de charpentier ambitieux, gravit les echelons de la societe de la Restauration.', 2, 2, @stendhal),
('La Chartreuse de Parme', '9782070413010', 1839, 'Gallimard', 'Fabrice Del Dongo traverse les guerres napoleoniennes et les intrigues de cour.', 2, 2, @stendhal),
('Le Pere Goriot', '9782070413027', 1835, 'Gallimard', 'Le pere Goriot se ruine pour ses filles ingrates dans une pension bourgeoise de Paris.', 2, 2, @balzac),
('Eugenie Grandet', '9782070413034', 1833, 'Gallimard', 'Eugenie Grandet souffre sous la tyrannie de son pere avare avant de trouver l amour.', 2, 2, @balzac),
('Les Trois Mousquetaires', '9782070413041', 1844, 'Gallimard', 'D Artagnan rejoint les trois mousquetaires Athos, Porthos et Aramis dans leurs aventures.', 3, 3, @dumas),
('Le Comte de Monte-Cristo', '9782070413058', 1844, 'Gallimard', 'Edmond Dantes, injustement emprisonne, s evade et ourdit une vengeance minutieuse.', 3, 3, @dumas),
('Le Misanthrope', '9782070413065', 1666, 'Gallimard', 'Alceste, d une intransigeance absolue, s oppose a la mondanite hypocrite de la cour.', 2, 2, @moliere),
('L Avare', '9782070413072', 1668, 'Gallimard', 'Harpagon, avare tyrannique, s oppose au mariage de ses enfants par cupidite.', 2, 2, @moliere),
('Dom Juan', '9782070413089', 1665, 'Gallimard', 'Dom Juan, seducteur libertin, defie Dieu et la mort jusqu a sa damnation.', 2, 2, @moliere),
('Candide', '9782070413096', 1759, 'Gallimard', 'Candide parcourt le monde et remet en cause l optimisme naif face a la misere et l injustice.', 3, 3, @voltaire),
('Zadig', '9782070413102', 1747, 'Gallimard', 'Zadig, jeune Babylonien sage, subit les caprices du destin et la mechancete des hommes.', 2, 2, @voltaire),
('La Nausee', '9782070360284', 1938, 'Gallimard', 'Antoine Roquentin eprouve une nausee existentielle face a l absurdite de l existence a Bouville.', 2, 2, @sartre),
('Huis clos', '9782070360291', 1944, 'Gallimard', 'Trois personnages enfermes en enfer decouvrent que l enfer c est les autres.', 3, 3, @sartre),
('Le Deuxieme Sexe', '9782070360314', 1949, 'Gallimard', 'Essai fondateur du feminisme moderne : on ne nait pas femme, on le devient.', 2, 2, @beauvoir),
('Les Mandarins', '9782070360321', 1954, 'Gallimard', 'Tableau de l intelligentsia parisienne apres-guerre entre engagement politique et vie privee.', 1, 1, @beauvoir),
('Bel-Ami', '9782070413171', 1885, 'Gallimard', 'Georges Duroy, arriviste sans scrupules, gravit les echelons de la societe parisienne grace aux femmes.', 2, 2, @maupassant),
('Une vie', '9782070413188', 1883, 'Gallimard', 'Jeanne, jeune normande idealiste, voit ses illusions s effondrer au fil d une vie decevante.', 2, 2, @maupassant),
('Vingt mille lieues sous les mers', '9782070413195', 1870, 'Hetzel', 'Le professeur Aronnax est prisonnier du mysterieux capitaine Nemo a bord du Nautilus.', 3, 3, @verne),
('Le Tour du monde en 80 jours', '9782070413201', 1872, 'Hetzel', 'Phileas Fogg parie qu il fera le tour du monde en 80 jours avec son valet Passepartout.', 3, 3, @verne),
('Voyage au centre de la Terre', '9782070413218', 1864, 'Hetzel', 'Le professeur Lidenbrock descend dans les entrailles de la Terre par un volcan islandais.', 2, 2, @verne),
('De la Terre a la Lune', '9782070413225', 1865, 'Hetzel', 'Trois membres du Gun-Club tentent de voyager jusqu a la Lune a bord d un projectile.', 2, 2, @verne),
('Shining', '9782253049951', 1977, 'Livre de Poche', 'Jack Torrance, gardien d un hotel isole, sombre dans la folie sous l influence de forces malefiques.', 2, 2, @king),
('Ca', '9782253049944', 1986, 'Livre de Poche', 'Sept enfants de Derry affrontent une entite malefique qui se manifeste sous la forme d un clown.', 2, 2, @king),
('Carrie', '9782253049937', 1974, 'Livre de Poche', 'Carrie White, adolescente persecutee, decouvre des pouvoirs telekinetiques et se venge lors du bal de promo.', 2, 2, @king),
('Le Meurtre de Roger Ackroyd', '9782702430118', 1926, 'Le Masque', 'Hercule Poirot enquete sur un meurtre dans un village anglais et demasque un coupable inattendu.', 3, 3, @christie),
('Dix Petits Negres', '9782702430125', 1939, 'Le Masque', 'Dix etrangers sont reunis sur une ile et meurent les uns apres les autres selon une comptine.', 3, 3, @christie),
('Mort sur le Nil', '9782702430132', 1937, 'Le Masque', 'Hercule Poirot se retrouve mele a un meurtre lors d une croisiere sur le Nil.', 2, 2, @christie),
('Une etude en rouge', '9782070413232', 1887, 'Gallimard', 'Premiere aventure de Sherlock Holmes et du Dr Watson, liee a une secte de Mormons.', 2, 2, @doyle),
('Le Chien des Baskerville', '9782070413249', 1902, 'Gallimard', 'Holmes enquete sur la malediction d une famille anglaise liee a un chien fantome sur les landes.', 3, 3, @doyle),
('Le Vieil Homme et la Mer', '9782070413256', 1952, 'Gallimard', 'Santiago, vieux pecheur cubain, lutte seul en mer trois jours pour attraper un enorme espadon.', 2, 2, @hemingway),
('L Adieu aux armes', '9782070413263', 1929, 'Gallimard', 'Un officier americain tombe amoureux d une infirmiere britannique pendant la Premiere Guerre mondiale.', 2, 2, @hemingway),
('Gatsby le Magnifique', '9782070413270', 1925, 'Gallimard', 'Jay Gatsby organise des fetes fastueuses pour reconquerir Daisy, son amour de jeunesse.', 3, 3, @fitzgerald),
('Les Raisins de la colere', '9782070413287', 1939, 'Gallimard', 'La famille Joad, ruinee par la Grande Depression, migre vers la Californie en quete d une vie meilleure.', 2, 2, @steinbeck),
('Des souris et des hommes', '9782070413294', 1937, 'Gallimard', 'George et Lennie, deux ouvriers itinerants, partagent le reve d avoir leur propre ferme.', 2, 2, @steinbeck),
('Cent ans de solitude', '9782020006994', 1967, 'Seuil', 'L epopee de la famille Buendia a Macondo, ville imaginaire d Amerique latine, sur plusieurs generations.', 2, 2, @marquez),
('L Amour aux temps du cholera', '9782020006997', 1985, 'Seuil', 'Florentino Ariza attend plus de cinquante ans pour conquerir Fermina Daza, l amour de sa jeunesse.', 2, 2, @marquez),
('La Metamorphose', '9782070413300', 1915, 'Gallimard', 'Gregor Samsa se reveille transforme en insecte geant et observe sa famille se detourner de lui.', 3, 3, @kafka),
('Le Proces', '9782070413317', 1925, 'Gallimard', 'Josef K. est arrete et juge sans jamais connaitre le crime dont on l accuse.', 2, 2, @kafka),
('Le Chateau', '9782070413324', 1926, 'Gallimard', 'K., arpenteur, tente vainement d atteindre l autorite mysterieuse du Chateau qui regit un village.', 2, 2, @kafka),
('Crime et Chatiment', '9782070413331', 1866, 'Gallimard', 'Raskolnikov commet un meurtre pour prouver sa theorie sur les hommes superieurs et sombre dans la culpabilite.', 2, 2, @dostoievski),
('Les Freres Karamazov', '9782070413348', 1880, 'Gallimard', 'Les trois freres Karamazov s affrontent autour du meurtre de leur pere en Russie.', 2, 2, @dostoievski),
('L Idiot', '9782070413355', 1869, 'Gallimard', 'Le prince Mychkine, homme d une bonte absolue, se heurte a la corruption humaine a Saint-Petersbourg.', 1, 1, @dostoievski),
('Guerre et Paix', '9782070413362', 1869, 'Gallimard', 'Vaste fresque de la societe russe pendant les guerres napoleoniennes a travers plusieurs familles.', 2, 2, @tolstoi),
('Anna Karenine', '9782070413379', 1877, 'Gallimard', 'Anna Karenine quitte son mari pour un officier seduisant et s achemine vers une tragedie inevitable.', 2, 2, @tolstoi),
('Le Hobbit', '9782070612024', 1937, 'Gallimard', 'Bilbo Sacquet est entraine par Gandalf dans une quete pour reprendre un tresor garde par un dragon.', 4, 4, @tolkien),
('La Communaute de l Anneau', '9782070612031', 1954, 'Gallimard', 'Frodon et ses compagnons partent detruire l Anneau Unique dans la montagne du Destin.', 3, 3, @tolkien),
('Les Deux Tours', '9782070612048', 1954, 'Gallimard', 'La Communaute est brisee. Frodon poursuit sa quete vers le Mordor tandis qu Aragorn combat en Rohan.', 3, 3, @tolkien),
('Le Retour du Roi', '9782070612055', 1955, 'Gallimard', 'La guerre de l Anneau atteint son apogee tandis que Frodon approche du but.', 3, 3, @tolkien),
('Fondation', '9782070612062', 1951, 'Gallimard', 'Hari Seldon cree la Fondation pour preserver la civilisation galactique face a la chute de l Empire.', 3, 3, @asimov),
('Les Robots', '9782070612079', 1950, 'Gallimard', 'Recueil de nouvelles explorant les trois lois de la robotique et leurs paradoxes.', 2, 2, @asimov),
('Le Cycle des robots', '9782070612086', 1954, 'Gallimard', 'Le detective Elijah Baley enquete avec le robot R. Daneel Olivaw sur des crimes interplanetaires.', 2, 2, @asimov);

-- Exemplaires automatiques
INSERT INTO exemplaire (id_livre, code_barre, est_disponible)
SELECT l.id_livre, CONCAT('EX', LPAD(l.id_livre, 4, '0'), CHAR(64 + n.n)), TRUE
FROM livre l
JOIN (SELECT 1 AS n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) n ON n.n <= l.nb_exemplaires_total
WHERE l.id_livre NOT IN (SELECT DISTINCT id_livre FROM exemplaire);