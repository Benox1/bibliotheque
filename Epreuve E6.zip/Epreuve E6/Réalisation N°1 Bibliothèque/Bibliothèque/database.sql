CREATE DATABASE IF NOT EXISTS bibliotheque
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE bibliotheque;

-- ------------------------------------------------
-- Table ROLE
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS role (
    id_role       INT          NOT NULL AUTO_INCREMENT,
    libelle_role  VARCHAR(50)  NOT NULL UNIQUE,
    description   TEXT         NULL,
    PRIMARY KEY (id_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------
-- Table UTILISATEUR
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS utilisateur (
    id_utilisateur  INT          NOT NULL AUTO_INCREMENT,
    nom             VARCHAR(100) NOT NULL,
    prenom          VARCHAR(100) NOT NULL,
    email           VARCHAR(255) NOT NULL UNIQUE,
    mot_de_passe    VARCHAR(255) NOT NULL,
    telephone       VARCHAR(15)  NULL,
    adresse         VARCHAR(255) NULL,
    date_inscription DATE        NOT NULL DEFAULT (CURRENT_DATE),
    id_role         INT          NOT NULL,
    PRIMARY KEY (id_utilisateur),
    CONSTRAINT fk_utilisateur_role FOREIGN KEY (id_role) REFERENCES role(id_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------
-- Table AUTEUR
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS auteur (
    id_auteur  INT          NOT NULL AUTO_INCREMENT,
    nom        VARCHAR(150) NOT NULL,
    PRIMARY KEY (id_auteur)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------
-- Table LIVRE
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS livre (
    id_livre               INT          NOT NULL AUTO_INCREMENT,
    titre                  VARCHAR(255) NOT NULL,
    isbn                   VARCHAR(20)  NOT NULL UNIQUE,
    annee_publication      INT         NULL,
    editeur                VARCHAR(150) NULL,
    resume                 TEXT         NULL,
    couverture_url         VARCHAR(500) NULL,
    nb_exemplaires_total   INT          NOT NULL DEFAULT 0,
    nb_exemplaires_dispo   INT          NOT NULL DEFAULT 0,
    id_auteur              INT          NOT NULL,
    date_ajout             DATE         NOT NULL DEFAULT (CURRENT_DATE),
    PRIMARY KEY (id_livre),
    CONSTRAINT fk_livre_auteur FOREIGN KEY (id_auteur) REFERENCES auteur(id_auteur)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------
-- Table EXEMPLAIRE
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS exemplaire (
    id_exemplaire  INT         NOT NULL AUTO_INCREMENT,
    id_livre       INT         NOT NULL,
    code_barre     VARCHAR(50) NOT NULL UNIQUE,
    est_disponible BOOLEAN     NOT NULL DEFAULT TRUE,
    PRIMARY KEY (id_exemplaire),
    CONSTRAINT fk_exemplaire_livre FOREIGN KEY (id_livre) REFERENCES livre(id_livre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------
-- Table EMPRUNT
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS emprunt (
    id_emprunt           INT  NOT NULL AUTO_INCREMENT,
    id_utilisateur       INT  NOT NULL,
    id_exemplaire        INT  NOT NULL,
    date_emprunt         DATE NOT NULL,
    date_retour_prevue   DATE NOT NULL,
    date_retour_effective DATE NULL,
    statut               ENUM('en_cours','retourne','en_retard') NOT NULL DEFAULT 'en_cours',
    PRIMARY KEY (id_emprunt),
    CONSTRAINT fk_emprunt_utilisateur FOREIGN KEY (id_utilisateur) REFERENCES utilisateur(id_utilisateur),
    CONSTRAINT fk_emprunt_exemplaire  FOREIGN KEY (id_exemplaire)  REFERENCES exemplaire(id_exemplaire)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------
-- Table PROLONGATION
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS prolongation (
    id_prolongation      INT  NOT NULL AUTO_INCREMENT,
    id_emprunt           INT  NOT NULL UNIQUE,
    date_demande         DATE NOT NULL,
    nouvelle_date_retour DATE NOT NULL,
    duree_prolongation   INT  NOT NULL DEFAULT 10,
    PRIMARY KEY (id_prolongation),
    CONSTRAINT fk_prolongation_emprunt FOREIGN KEY (id_emprunt) REFERENCES emprunt(id_emprunt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------
-- Table AUDIT_LOG
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id_log      INT          NOT NULL AUTO_INCREMENT,
    action      VARCHAR(100) NOT NULL,
    detail      TEXT         NULL,
    id_auteur   INT          NULL,
    date_action DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_log),
    CONSTRAINT fk_audit_utilisateur FOREIGN KEY (id_auteur) REFERENCES utilisateur(id_utilisateur) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ================================================
-- Données initiales
-- ================================================

-- Rôles
INSERT INTO role (libelle_role, description) VALUES
  ('adherent',      'Adhérent — peut emprunter jusqu''à 3 livres simultanément'),
  ('administrateur','Administrateur — accès complet au système');

-- Auteurs exemple
INSERT INTO auteur (nom) VALUES
  ('Victor Hugo'),
  ('Albert Camus'),
  ('J.K. Rowling'),
  ('George Orwell'),
  ('Antoine de Saint-Exupéry');

-- Livres exemple
INSERT INTO livre (titre, isbn, annee_publication, editeur, resume, nb_exemplaires_total, nb_exemplaires_dispo, id_auteur) VALUES
  ('Les Misérables',          '9782070409228', 1862, 'Gallimard',      'Roman historique et social.', 3, 3, 1),
  ('Notre-Dame de Paris',     '9782070360024', 1831, 'Gallimard',      'Drame romantique médiéval.',  2, 2, 1),
  ('L''Étranger',             '9782070360028', 1942, 'Gallimard',      'Roman existentialiste.',      2, 2, 2),
  ('La Peste',                '9782070360031', 1947, 'Gallimard',      'Chronique d''une épidémie.',  3, 3, 2),
  ('Harry Potter à l''école', '9782070541270', 1997, 'Gallimard',      'Premier tome HP.',            4, 4, 3),
  ('1984',                    '9782070368228', 1949, 'Gallimard',      'Dystopie totalitaire.',       2, 2, 4),
  ('Le Petit Prince',         '9782070612758', 1943, 'Gallimard',      'Conte philosophique.',        3, 3, 5);

-- Exemplaires (code_barre = EX + id_livre + lettre)
INSERT INTO exemplaire (id_livre, code_barre, est_disponible) VALUES
  (1,'EX001A',TRUE),(1,'EX001B',TRUE),(1,'EX001C',TRUE),
  (2,'EX002A',TRUE),(2,'EX002B',TRUE),
  (3,'EX003A',TRUE),(3,'EX003B',TRUE),
  (4,'EX004A',TRUE),(4,'EX004B',TRUE),(4,'EX004C',TRUE),
  (5,'EX005A',TRUE),(5,'EX005B',TRUE),(5,'EX005C',TRUE),(5,'EX005D',TRUE),
  (6,'EX006A',TRUE),(6,'EX006B',TRUE),
  (7,'EX007A',TRUE),(7,'EX007B',TRUE),(7,'EX007C',TRUE);
